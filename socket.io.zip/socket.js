﻿exports.Socket = {
    OpenSocket : function (app, port) { 
        console.log("opening new socket at " + port);
        var io = require('socket.io').listen(port);
        io.on('connection', function (socket) {
            console.log(socket.handshake.query.name)
            socket.emit('welcome', { message: 'connected!' , id : socket.id });
            socket.on(socket.handshake.query.name, function (request) {
                socket.emit(socket.handshake.query.name, request);
            });
        });
    }
}

