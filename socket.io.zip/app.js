﻿var http = require('http'),
    fs = require('fs'),
    // NEVER use a Sync function except at start-up!
    index = fs.readFileSync(__dirname + '/test.html'),
    Socket = require('./socket'),
    Twilio = require('./twillio'),
    port = 3000;

// Send index.html to all requests
var app = http.createServer(function (req, res) {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(index);
});
app.listen(port, function () {
    console.log('app started at localhost at port ' + port);
    Socket.Socket.OpenSocket(app, 5100)
});
exports.app = app;